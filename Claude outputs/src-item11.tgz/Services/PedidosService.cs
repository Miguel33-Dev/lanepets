using LanePets.Data;
using LanePets.Models;

namespace LanePets.Services;

/// <summary>
/// Itens 6/7 do roadmap (24/09): ciclo de vida do pedido da loja.
///   Pendente -> Confirmado -> Entregue      (+ Cancelado, que e final)
/// Cancelar devolve ao estoque o que o pedido baixou (decisao do Fabricio),
/// pela movimentacao "cancelamento" do livro de estoque.
/// Status de pedido NAO tem relacao com status de agendamento (item 4).
/// </summary>
public static class PedidosService
{
    public const string Pendente = "Pendente";
    public const string Confirmado = "Confirmado";
    public const string Entregue = "Entregue";
    public const string Cancelado = "Cancelado";
    public static readonly string[] Todos = [Pendente, Confirmado, Entregue, Cancelado];

    public static string Normalizar(string? valor) => Normalizador.Texto(valor) switch
    {
        "pendente" => Pendente,
        "confirmado" => Confirmado,
        "entregue" or "retirado" => Entregue,
        "cancelado" => Cancelado,
        _ => ""
    };

    public static string Exibir(string? valor) => Normalizar(valor) is { Length: > 0 } s ? s : Pendente;

    /// <summary>
    /// Muda o status (sem SaveChanges — quem chama salva). Devolve quantas
    /// unidades voltaram ao estoque (0 quando nao cancelou ou nao havia baixa).
    /// </summary>
    public static async Task<int> AlterarStatusAsync(LanePetsDbContext db, Pedido pedido, string? novoStatus,
        string autorId, string autor, string origem)
    {
        var novo = Normalizar(novoStatus);
        if (novo.Length == 0) throw new Exception($"Status inválido. Use: {string.Join(", ", Todos)}.");
        var atual = Exibir(pedido.Status);
        if (atual == Cancelado) throw new Exception("Este pedido já foi cancelado e não pode mudar de status.");
        if (atual == novo) return 0;

        pedido.Status = novo;
        if (novo != Cancelado) return 0;
        var (devolvido, _) = await EstoqueService.DevolverPedidoAsync(db, pedido, autorId, autor, origem);
        return devolvido;
    }
}
