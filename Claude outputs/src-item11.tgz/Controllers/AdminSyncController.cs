using System.Text.Json;
using LanePets.Data;
using LanePets.Models;
using LanePets.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LanePets.Controllers;

/// <summary>
/// Leitura consolidada para o painel administrativo, calculada no servidor a
/// partir do lanepets.db — o mesmo banco que a area do cliente grava.
///
/// Por que este controller existe: as telas do painel liam o localStorage do
/// navegador, entao nada que o cliente fazia chegava ao admin. Aqui ficam os
/// numeros do dashboard e as listas que faltavam na API (produtos com estoque,
/// lancamentos financeiros, pacotes e pedidos), mais a importacao do que ainda
/// so existia no navegador. Nenhum endpoint antigo foi alterado.
/// </summary>
[Route("api/admin")]
public class AdminSyncController(LanePetsDbContext db, PermissaoService permissoes, RealtimeNotifier realtime, EventosService eventos) : ApiControllerBase
{
    // -----------------------------------------------------------------------
    // DASHBOARD
    // -----------------------------------------------------------------------

    /// <summary>Todos os indicadores do painel, calculados sobre os dados reais.</summary>
    [HttpGet("resumo")]
    public async Task<IActionResult> Resumo([FromQuery] string token = "", [FromQuery] string? de = null, [FromQuery] string? ate = null, [FromQuery] string? unidade = "todas")
    {
        try
        {
            // O resumo cruza agenda com dinheiro, entao exige o Dashboard e,
            // para a parte financeira, tambem Pagamentos.
            var contexto = await permissoes.ExigirAsync(token, ModulosAdmin.Dashboard, AcaoPermissao.Visualizar);
            var podeFinanceiro = contexto.Pode(ModulosAdmin.Pagamentos, AcaoPermissao.Visualizar);

            // Funcionario (item 1) so enxerga a agenda da propria unidade.
            var agendamentos = (await db.Agendamentos.AsNoTracking().ToListAsync())
                .Where(a => contexto.VeUnidade(a.Unidade)).ToList();
            List<EntradaSaida> lancamentos = podeFinanceiro ? await db.EntradasESaidas.AsNoTracking().ToListAsync() : new();
            var pedidos = (await db.Pedidos.AsNoTracking().ToListAsync()).Where(p => contexto.VeUnidade(p.Unidade)).ToList();
            var produtos = await db.Produtos.AsNoTracking().ToListAsync();
            var servicosCadastrados = await db.Servicos.AsNoTracking().ToListAsync();

            var filtro = (unidade ?? "todas").Trim().ToLowerInvariant();
            var periodo = Calcular(agendamentos, lancamentos, pedidos, de, ate, filtro);

            // Item 9: pagamentos lidos da ENTIDADE Pagamento (item 8), nao do
            // campo espelho do agendamento. So para quem pode ver Pagamentos;
            // sem a permissao o dado nem sai do banco.
            var pagamentos = podeFinanceiro
                ? (await db.Pagamentos.AsNoTracking().ToListAsync())
                    .Where(p => contexto.VeUnidade(p.Unidade) && NaUnidade(p.Unidade, filtro)).ToList()
                : new List<Pagamento>();
            var pagamentosPendentes = pagamentos.Where(p => p.Status == PagamentosService.Pendente).ToList();
            var reembolsosPendentes = pagamentos.Count(p => p.ReembolsoPendente);
            var (deAnterior, ateAnterior) = PeriodoAnterior(de, ate);
            var anterior = Calcular(agendamentos, lancamentos, pedidos, deAnterior, ateAnterior, filtro);

            var porUnidade = IdsPorUnidade().Select(u =>
            {
                var d = Calcular(agendamentos, lancamentos, pedidos, de, ate, u);
                return new
                {
                    id = u,
                    nome = NomeUnidade(u),
                    receita = d.Receita,
                    despesas = d.Despesas,
                    resultado = d.Resultado,
                    margem = d.Margem,
                    atendimentos = d.Atendimentos.Count,
                    ticket = d.Ticket
                };
            }).ToList();

            var alertas = new List<string>();
            if (pagamentosPendentes.Count > 0) alertas.Add($"{pagamentosPendentes.Count} pagamento(s) pendente(s), somando {pagamentosPendentes.Sum(p => p.Valor):C}.");
            if (reembolsosPendentes > 0) alertas.Add($"{reembolsosPendentes} reembolso(s) pendente(s) em Financeiro > Pagamentos.");
            if (podeFinanceiro && periodo.Resultado < 0) alertas.Add("O resultado do periodo esta negativo. Revise despesas e recebimentos.");
            if (agendamentos.Any(a => string.IsNullOrWhiteSpace(Normalizador.Unidade(a.Unidade)))) alertas.Add("Ha agendamentos sem unidade definida; eles aparecem como \"Sem unidade / antigos\".");
            var semEstoque = produtos.Where(p => p.ControlaEstoque && p.Estoque <= p.EstoqueMinimo).OrderBy(p => p.Estoque).ToList();
            if (semEstoque.Count > 0) alertas.Add($"{semEstoque.Count} produto(s) no estoque minimo ou abaixo dele.");
            var avaliacoesPendentes = await db.Depoimentos.CountAsync(d => d.Status == "Pendente");
            if (avaliacoesPendentes > 0) alertas.Add($"{avaliacoesPendentes} avaliacao(oes) aguardando moderacao.");
            var segurosPendentes = await db.SolicitacoesSeguro.CountAsync(s => s.Status == "Pendente");
            if (segurosPendentes > 0) alertas.Add($"{segurosPendentes} solicitacao(oes) de seguro aguardando contato.");
            if (alertas.Count == 0) alertas.Add("Nenhum alerta importante para o periodo selecionado.");

            var totalClientes = await db.Clientes.CountAsync();
            var totalPets = await db.Pets.CountAsync();

            // Item 9: agenda de HOJE (unidade do filtro, sem cancelados).
            var hojeDia = DateTime.Now.ToString("yyyy-MM-dd");
            var agendaHoje = agendamentos
                .Where(a => Normalizador.Data(a.DataHora) == hojeDia && NaUnidade(a.Unidade, filtro)
                         && StatusAgendamento.Exibir(a.Status) != StatusAgendamento.Cancelado)
                .ToList();

            // Item 9: servicos mais realizados no periodo, por frequencia (o valor
            // de cada servico nao fica gravado separado, entao nao ha receita por servico).
            var nomesServicos = servicosCadastrados.GroupBy(s => s.Id).ToDictionary(g => g.Key, g => g.First().Nome);
            var contagemServicos = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var a in periodo.Atendimentos)
                foreach (var nome in NomesDosServicos(a.ServicosJson, nomesServicos))
                    contagemServicos[nome] = contagemServicos.TryGetValue(nome, out var n) ? n + 1 : 1;
            var topServicos = contagemServicos.Select(kv => new { servico = kv.Key, quantidade = kv.Value })
                .OrderByDescending(s => s.quantidade).ThenBy(s => s.servico).Take(5).ToList();

            // Sem permissao de Pagamentos, nenhum valor em dinheiro sai daqui
            // (mesma regra do GET /api/admin/dashboard). A tela mostra "Restrito".
            decimal M(decimal valor) => podeFinanceiro ? valor : 0m;

            return OkApi(new
            {
                periodo = new { de, ate, unidade = filtro },
                restrito = !podeFinanceiro,
                // Item 9: os 8 indicadores principais do topo do dashboard.
                indicadores = new
                {
                    clientes = totalClientes,
                    pets = totalPets,
                    agendamentosHoje = agendaHoje.Count,
                    agendaHoje = new
                    {
                        solicitados = agendaHoje.Count(a => StatusAgendamento.Exibir(a.Status) == StatusAgendamento.Solicitado),
                        confirmados = agendaHoje.Count(a => StatusAgendamento.Exibir(a.Status) == StatusAgendamento.Confirmado),
                        emAndamento = agendaHoje.Count(a => StatusAgendamento.Exibir(a.Status) == StatusAgendamento.EmAndamento),
                        concluidos = agendaHoje.Count(a => StatusAgendamento.Exibir(a.Status) == StatusAgendamento.Concluido)
                    },
                    agendamentosPeriodo = periodo.Atendimentos.Count,
                    faturamento = podeFinanceiro ? periodo.Receita : (decimal?)null,
                    estoqueBaixo = semEstoque.Count,
                    semEstoque = semEstoque.Count(p => p.Estoque <= 0),
                    pagamentosPendentes = podeFinanceiro ? pagamentosPendentes.Count : (int?)null,
                    valorPendente = podeFinanceiro ? pagamentosPendentes.Sum(p => p.Valor) : (decimal?)null,
                    reembolsosPendentes = podeFinanceiro ? reembolsosPendentes : (int?)null,
                    servicosMaisRealizados = topServicos
                },
                totais = new
                {
                    clientes = totalClientes,
                    pets = totalPets,
                    agendamentos = agendamentos.Count,
                    agendamentosAtivos = agendamentos.Count(a => Normalizador.Status(a.Status) != "Cancelado"),
                    agendamentosCancelados = agendamentos.Count(a => Normalizador.Status(a.Status) == "Cancelado"),
                    pedidos = pedidos.Count,
                    produtos = produtos.Count,
                    servicos = await db.Servicos.CountAsync(),
                    planosSeguro = await db.PlanosSeguro.CountAsync(p => p.Ativo),
                    solicitacoesSeguro = await db.SolicitacoesSeguro.CountAsync(),
                    // Contagens reais da tabela de contratos: nada fixo na tela.
                    segurosAtivos = await db.SolicitacoesSeguro.CountAsync(s => s.Status != "Cancelada"),
                    segurosCancelados = await db.SolicitacoesSeguro.CountAsync(s => s.Status == "Cancelada"),
                    segurosPagamentosPendentes = await db.SolicitacoesSeguro.CountAsync(s => s.Status != "Cancelada" && s.PagamentoStatus == "Pendente"),
                    avaliacoes = await db.Depoimentos.CountAsync(),
                    avaliacoesPendentes,
                    contasDeCliente = await db.UsuariosClientes.CountAsync()
                },
                financeiro = new
                {
                    receita = M(periodo.Receita),
                    despesas = M(periodo.Despesas),
                    resultado = M(periodo.Resultado),
                    margem = M(periodo.Margem),
                    atendimentos = periodo.Atendimentos.Count,
                    ticketMedio = M(periodo.Ticket)
                },
                anterior = new
                {
                    de = deAnterior,
                    ate = ateAnterior,
                    receita = M(anterior.Receita),
                    despesas = M(anterior.Despesas),
                    resultado = M(anterior.Resultado),
                    atendimentos = anterior.Atendimentos.Count
                },
                operacional = new
                {
                    atendimentos = periodo.Atendimentos.Count,
                    pagos = periodo.PagamentosPagos,
                    pendentes = periodo.PagamentosPendentes,
                    transporteFaturado = M(periodo.Transporte),
                    cancelados = periodo.Cancelados,
                    pedidosDoPeriodo = periodo.Pedidos.Count,
                    receitaDePedidos = M(periodo.ReceitaPedidos)
                },
                categorias = podeFinanceiro
                    ? periodo.Categorias.Where(c => c.Value > 0).OrderByDescending(c => c.Value).Select(c => new { nome = c.Key, valor = c.Value }).ToList()
                    : new(),
                porUnidade = podeFinanceiro ? porUnidade : new(),
                mensal = podeFinanceiro ? SerieMensal(agendamentos, lancamentos, pedidos, filtro) : Array.Empty<object>(),
                estoqueBaixoTotal = semEstoque.Count,
                estoqueBaixo = semEstoque.Take(10).Select(p => new { p.Id, p.Codigo, p.Nome, p.Estoque, p.EstoqueMinimo, situacao = EstoqueService.Situacao(p), p.VisivelLoja }),
                alertas,
                atualizadoEm = DateTime.UtcNow.ToString("O")
            });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    private sealed record Consolidado(
        List<Agendamento> Atendimentos, List<Pedido> Pedidos, decimal Receita, decimal ReceitaPedidos,
        decimal Despesas, decimal Transporte, int PagamentosPagos, int PagamentosPendentes, int Cancelados,
        Dictionary<string, decimal> Categorias)
    {
        public decimal Resultado => Receita - Despesas;
        public decimal Margem => Receita == 0 ? 0 : Math.Round(Resultado / Receita * 100, 1);
        public decimal Ticket => Atendimentos.Count == 0 ? 0 : Math.Round(Receita / Atendimentos.Count, 2);
    }

    /// <summary>
    /// Consolida um periodo. Agendamentos cancelados NAO entram na receita nem
    /// na contagem de atendimentos — sao reportados a parte.
    /// </summary>
    private static Consolidado Calcular(List<Agendamento> agendamentos, List<EntradaSaida> lancamentos, List<Pedido> pedidos, string? de, string? ate, string filtroUnidade)
    {
        bool DaUnidade(string? valor)
        {
            if (filtroUnidade is "todas" or "") return true;
            // Item 5: lista de unidades dinamica. "sem-unidade" = registro antigo
            // ou gravado sem unidade reconhecida.
            var id = Normalizador.IdUnidade(valor);
            return filtroUnidade == "sem-unidade" ? id == "" : id == filtroUnidade;
        }

        var doPeriodo = agendamentos
            .Where(a => Normalizador.Dentro(Normalizador.Data(a.DataHora), de, ate) && DaUnidade(a.Unidade))
            .ToList();

        var cancelados = doPeriodo.Count(a => Normalizador.Status(a.Status) == "Cancelado");
        var ativos = doPeriodo.Where(a => Normalizador.Status(a.Status) != "Cancelado").ToList();

        var lancamentosDoPeriodo = lancamentos
            .Where(e => Normalizador.Dentro(Normalizador.Data(e.Data), de, ate) && DaUnidade(e.Unidade))
            .ToList();

        // Item 5: pedido tem unidade de retirada. Pedido antigo (sem unidade)
        // entra em "todas" e em "sem-unidade", como antes.
        var pedidosDoPeriodo = pedidos.Where(p => Normalizador.Dentro(p.CriadoEm.ToString("yyyy-MM-dd"), de, ate)
                                 && !string.Equals(p.Status, "Cancelado", StringComparison.OrdinalIgnoreCase)
                                 && DaUnidade(p.Unidade)).ToList();

        var receitaAgendamentos = ativos.Sum(a => a.Total);
        var receitaPedidos = pedidosDoPeriodo.Sum(p => p.Total);
        var entradasManuais = lancamentosDoPeriodo.Where(e => Normalizador.Texto(e.Tipo) == "entrada").Sum(e => e.Valor);
        var despesas = lancamentosDoPeriodo.Where(e => Normalizador.Texto(e.Tipo).StartsWith("saida") || Normalizador.Texto(e.Tipo) == "saida").Sum(e => e.Valor);

        var transporte = ativos.Sum(a => a.ValorTransporte);
        var categorias = new Dictionary<string, decimal>
        {
            ["Servicos"] = ativos.Sum(a => Math.Max(0, a.Total - a.ValorTransporte)),
            ["Transporte"] = transporte,
            ["Produtos"] = receitaPedidos,
            ["Outros"] = entradasManuais
        };

        return new Consolidado(
            ativos, pedidosDoPeriodo,
            receitaAgendamentos + receitaPedidos + entradasManuais,
            receitaPedidos, despesas, transporte,
            ativos.Count(a => Normalizador.Texto(a.PagamentoStatus) == "pago"),
            ativos.Count(a => Normalizador.Texto(a.PagamentoStatus) != "pago"),
            cancelados, categorias);
    }

    /// <summary>Mesmo criterio de unidade do Calcular(): "todas", "sem-unidade" ou o id da unidade.</summary>
    private static bool NaUnidade(string? valor, string filtroUnidade)
    {
        if (filtroUnidade is "todas" or "") return true;
        var id = Normalizador.IdUnidade(valor);
        return filtroUnidade == "sem-unidade" ? id == "" : id == filtroUnidade;
    }

    private static (string? De, string? Ate) PeriodoAnterior(string? de, string? ate)
    {
        if (!DateTime.TryParse(de, out var inicio) || !DateTime.TryParse(ate, out var fim)) return (null, null);
        var dias = (fim - inicio).Days + 1;
        var fimAnterior = inicio.AddDays(-1);
        return (fimAnterior.AddDays(-dias + 1).ToString("yyyy-MM-dd"), fimAnterior.ToString("yyyy-MM-dd"));
    }

    private static object SerieMensal(List<Agendamento> agendamentos, List<EntradaSaida> lancamentos, List<Pedido> pedidos, string filtroUnidade)
    {
        var hoje = DateTime.Today;
        return Enumerable.Range(0, 6).Select(i =>
        {
            var referencia = new DateTime(hoje.Year, hoje.Month, 1).AddMonths(-(5 - i));
            var de = referencia.ToString("yyyy-MM-dd");
            var ate = referencia.AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd");
            var d = Calcular(agendamentos, lancamentos, pedidos, de, ate, filtroUnidade);
            return new { mes = referencia.ToString("yyyy-MM"), receita = d.Receita, despesas = d.Despesas };
        }).ToArray();
    }

    private static string NomeUnidade(string id)
        => id == "sem-unidade" ? "Sem unidade / antigos" : (Normalizador.NomeUnidade(id) is { Length: > 0 } nome ? nome : id);

    /// <summary>Ids para o bloco "por unidade" dos relatorios: todas as unidades conhecidas + "sem-unidade".</summary>
    private static string[] IdsPorUnidade()
        => Normalizador.Unidades.Select(u => u.Id).Append("sem-unidade").ToArray();

    // -----------------------------------------------------------------------
    // RELATORIO FINANCEIRO — visao analitica dedicada, reaproveitando o
    // mesmo Calcular() do resumo. Nao duplica calculo nenhum: so acrescenta
    // as agregacoes que faltavam (formas de pagamento, serie adaptada ao
    // periodo, pedidos/pagamentos detalhados, top produtos e servicos).
    // -----------------------------------------------------------------------

    /// <summary>Visao analitica do Relatorio Financeiro (ADM > Financeiro > Relatorio).</summary>
    [HttpGet("relatorio")]
    public async Task<IActionResult> Relatorio([FromQuery] string token = "", [FromQuery] string? de = null, [FromQuery] string? ate = null, [FromQuery] string? unidade = "todas")
    {
        try
        {
            var contexto = await permissoes.ExigirAsync(token, ModulosAdmin.Relatorios, AcaoPermissao.Visualizar);
            var podeFinanceiro = contexto.Pode(ModulosAdmin.Pagamentos, AcaoPermissao.Visualizar);

            var agendamentos = await db.Agendamentos.AsNoTracking().ToListAsync();
            List<EntradaSaida> lancamentos = podeFinanceiro ? await db.EntradasESaidas.AsNoTracking().ToListAsync() : new();
            var pedidos = await db.Pedidos.AsNoTracking().ToListAsync();
            var servicosCadastrados = await db.Servicos.AsNoTracking().ToListAsync();

            var filtro = (unidade ?? "todas").Trim().ToLowerInvariant();
            var periodo = Calcular(agendamentos, lancamentos, pedidos, de, ate, filtro);
            var (deAnterior, ateAnterior) = PeriodoAnterior(de, ate);
            var anterior = (deAnterior != null && ateAnterior != null) ? Calcular(agendamentos, lancamentos, pedidos, deAnterior, ateAnterior, filtro) : null;

            decimal? Variacao(decimal atual, decimal baseAnterior) => baseAnterior == 0 ? null : Math.Round((atual - baseAnterior) / Math.Abs(baseAnterior) * 100, 1);

            var porUnidade = IdsPorUnidade().Select(u =>
            {
                var d = Calcular(agendamentos, lancamentos, pedidos, de, ate, u);
                return new
                {
                    id = u,
                    nome = NomeUnidade(u),
                    receita = d.Receita,
                    despesas = d.Despesas,
                    saldo = d.Resultado,
                    pedidos = d.Pedidos.Count,
                    atendimentos = d.Atendimentos.Count
                };
            }).Where(u => u.receita != 0 || u.despesas != 0 || u.pedidos != 0 || u.atendimentos != 0).ToList();

            var totalRecebidoAgendamentos = periodo.Atendimentos.Where(a => Normalizador.Texto(a.PagamentoStatus) == "pago").Sum(a => a.Total);

            // Pedidos do periodo, incluindo cancelados (necessario para o resumo de status).
            var pedidosPeriodoTodos = pedidos.Where(p => Normalizador.Dentro(p.CriadoEm.ToString("yyyy-MM-dd"), de, ate)).ToList();
            var pedidosResumo = new
            {
                total = pedidosPeriodoTodos.Count,
                pendentes = pedidosPeriodoTodos.Count(p => string.Equals(p.Status, "Pendente", StringComparison.OrdinalIgnoreCase)),
                confirmados = pedidosPeriodoTodos.Count(p => string.Equals(p.Status, "Confirmado", StringComparison.OrdinalIgnoreCase)),
                entregues = pedidosPeriodoTodos.Count(p => string.Equals(p.Status, "Entregue", StringComparison.OrdinalIgnoreCase)),
                cancelados = pedidosPeriodoTodos.Count(p => string.Equals(p.Status, "Cancelado", StringComparison.OrdinalIgnoreCase)),
                valorTotalPedidos = pedidosPeriodoTodos.Where(p => !string.Equals(p.Status, "Cancelado", StringComparison.OrdinalIgnoreCase)).Sum(p => p.Total),
                valorRecebido = periodo.ReceitaPedidos
            };

            var pagamentosResumo = new
            {
                pagos = periodo.PagamentosPagos,
                pendentes = periodo.PagamentosPendentes,
                cancelados = periodo.Cancelados,
                totalRecebido = totalRecebidoAgendamentos
            };

            // Formas de pagamento: agendamentos pagos + pedidos nao cancelados do periodo.
            var formas = new Dictionary<string, (int Quantidade, decimal Valor)>(StringComparer.OrdinalIgnoreCase);
            void Somar(string? forma, decimal valor)
            {
                var chave = string.IsNullOrWhiteSpace(forma) ? null : forma!.Trim();
                if (chave is null || string.Equals(chave, "A combinar", StringComparison.OrdinalIgnoreCase)) return;
                var atual = formas.TryGetValue(chave, out var v) ? v : (Quantidade: 0, Valor: 0m);
                formas[chave] = (atual.Quantidade + 1, atual.Valor + valor);
            }
            foreach (var a in periodo.Atendimentos.Where(a => Normalizador.Texto(a.PagamentoStatus) == "pago")) Somar(a.FormaPagamento, a.Total);
            foreach (var p in periodo.Pedidos) Somar(p.FormaPagamento, p.Total);
            var totalFormas = formas.Values.Sum(v => v.Valor);
            var formasPagamento = formas.Select(kv => new
            {
                forma = kv.Key,
                quantidade = kv.Value.Quantidade,
                valor = kv.Value.Valor,
                percentual = totalFormas == 0 ? 0 : Math.Round(kv.Value.Valor / totalFormas * 100, 1)
            }).OrderByDescending(f => f.valor).ToList();

            // Top produtos vendidos (pedidos nao cancelados do periodo).
            var topProdutos = periodo.Pedidos
                .GroupBy(p => string.IsNullOrWhiteSpace(p.ProdutoNome) ? "(sem nome)" : p.ProdutoNome)
                .Select(g => new { produto = g.Key, quantidade = g.Sum(p => p.Quantidade), receita = g.Sum(p => p.Total) })
                .OrderByDescending(g => g.receita).Take(5).ToList();

            // Top servicos realizados por frequencia — o valor de cada servico
            // dentro do agendamento nao fica gravado individualmente (so o
            // total do agendamento), entao nao inventamos receita por servico.
            var nomesServicos = servicosCadastrados.ToDictionary(s => s.Id, s => s.Nome);
            var contagemServicos = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var a in periodo.Atendimentos)
                foreach (var nome in NomesDosServicos(a.ServicosJson, nomesServicos))
                    contagemServicos[nome] = contagemServicos.TryGetValue(nome, out var n) ? n + 1 : 1;
            var topServicos = contagemServicos.Select(kv => new { servico = kv.Key, quantidade = kv.Value })
                .OrderByDescending(s => s.quantidade).Take(5).ToList();

            return OkApi(new
            {
                periodo = new { de, ate, unidade = filtro },
                restrito = !podeFinanceiro,
                cards = new
                {
                    entradas = periodo.Receita,
                    saidas = periodo.Despesas,
                    saldo = periodo.Resultado,
                    totalPagamentos = periodo.Atendimentos.Count + periodo.Pedidos.Count,
                    ticketMedio = periodo.Ticket
                },
                variacao = anterior is null ? null : new
                {
                    entradas = Variacao(periodo.Receita, anterior.Receita),
                    saidas = Variacao(periodo.Despesas, anterior.Despesas),
                    saldo = Variacao(periodo.Resultado, anterior.Resultado)
                },
                categorias = periodo.Categorias.Where(c => c.Value > 0).OrderByDescending(c => c.Value).Select(c => new { nome = c.Key, valor = c.Value }),
                formasPagamento,
                porUnidade,
                pedidosResumo,
                pagamentosResumo,
                topProdutos,
                topServicos,
                serie = SeriePeriodo(agendamentos, lancamentos, pedidos, de, ate, filtro),
                atualizadoEm = DateTime.UtcNow.ToString("O")
            });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    private static IEnumerable<string> NomesDosServicos(string? servicosJson, Dictionary<string, string> nomesPorId)
    {
        if (string.IsNullOrWhiteSpace(servicosJson)) yield break;
        JsonDocument doc;
        try { doc = JsonDocument.Parse(servicosJson); } catch { yield break; }
        using (doc)
        {
            if (doc.RootElement.ValueKind != JsonValueKind.Array) yield break;
            foreach (var item in doc.RootElement.EnumerateArray())
            {
                string? nome = null;
                if (item.ValueKind == JsonValueKind.Object)
                {
                    if (item.TryGetProperty("nome", out var n) && n.ValueKind == JsonValueKind.String) nome = n.GetString();
                    if (string.IsNullOrWhiteSpace(nome) && item.TryGetProperty("id", out var idEl) && idEl.ValueKind == JsonValueKind.String)
                        nomesPorId.TryGetValue(idEl.GetString() ?? "", out nome);
                }
                else if (item.ValueKind == JsonValueKind.String) nome = item.GetString();
                if (!string.IsNullOrWhiteSpace(nome)) yield return nome!.Trim();
            }
        }
    }

    /// <summary>
    /// Serie de receita/despesa/saldo adaptada ao tamanho do periodo: diaria
    /// ate 31 dias, semanal ate 180 dias, mensal acima disso — nunca gera mais
    /// que ~60 pontos, entao o grafico/tabela no navegador fica legivel.
    /// </summary>
    private static List<object> SeriePeriodo(List<Agendamento> agendamentos, List<EntradaSaida> lancamentos, List<Pedido> pedidos, string? de, string? ate, string filtroUnidade)
    {
        if (!DateTime.TryParse(de, out var inicio) || !DateTime.TryParse(ate, out var fim) || fim < inicio)
            return new();

        var dias = (fim - inicio).Days + 1;
        var pontos = new List<(string Rotulo, DateTime Inicio, DateTime Fim)>();

        if (dias <= 31)
        {
            for (var d = inicio; d <= fim; d = d.AddDays(1))
                pontos.Add((d.ToString("dd/MM"), d, d));
        }
        else if (dias <= 180)
        {
            var cursor = inicio;
            while (cursor <= fim)
            {
                var fimSemana = cursor.AddDays(6) > fim ? fim : cursor.AddDays(6);
                pontos.Add(($"{cursor:dd/MM}-{fimSemana:dd/MM}", cursor, fimSemana));
                cursor = fimSemana.AddDays(1);
            }
        }
        else
        {
            var cursor = new DateTime(inicio.Year, inicio.Month, 1);
            while (cursor <= fim)
            {
                var fimMes = cursor.AddMonths(1).AddDays(-1);
                pontos.Add((cursor.ToString("MM/yyyy"), cursor < inicio ? inicio : cursor, fimMes > fim ? fim : fimMes));
                cursor = cursor.AddMonths(1);
            }
        }

        return pontos.Select(p =>
        {
            var d = Calcular(agendamentos, lancamentos, pedidos, p.Inicio.ToString("yyyy-MM-dd"), p.Fim.ToString("yyyy-MM-dd"), filtroUnidade);
            return (object)new { periodo = p.Rotulo, receita = d.Receita, despesas = d.Despesas, saldo = d.Resultado };
        }).ToList();
    }

    // -----------------------------------------------------------------------
    // LISTAS QUE FALTAVAM NA API
    // -----------------------------------------------------------------------

    [HttpGet("produtos")]
    public async Task<IActionResult> Produtos([FromQuery] string token = "")
    {
        try
        {
            await permissoes.ExigirAsync(token, ModulosAdmin.Produtos, AcaoPermissao.Visualizar);
            var produtos = await db.Produtos.AsNoTracking().OrderBy(p => p.Nome).ToListAsync();
            return OkApi(produtos.Select(p => new { p.Id, p.Codigo, p.Nome, p.Categoria, p.ValorCompra, p.ValorVenda, p.Estoque, p.EstoqueMinimo, p.ControlaEstoque, p.VisivelLoja, situacaoEstoque = EstoqueService.Situacao(p), margem = p.ValorCompra == 0 ? 0 : Math.Round((p.ValorVenda - p.ValorCompra) / p.ValorCompra * 100, 1) }));
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    /// <summary>Ajusta o estoque de um produto. Unica escrita desta fase: sem ela o
    /// controle de estoque nao teria como ser ligado por quem usa o painel.</summary>
    [HttpPost("produtos/{id}/estoque")]
    public async Task<IActionResult> AjustarEstoque(string id, [FromBody] EstoqueRequest request)
    {
        try
        {
            // Ajustar estoque altera o produto: exige Produtos > Editar.
            var contextoEstoque = await permissoes.ExigirAsync(request.Token ?? "", ModulosAdmin.Produtos, AcaoPermissao.Editar);
            var produto = await db.Produtos.FindAsync(id) ?? throw new Exception("Produto nao encontrado.");
            var estoqueAnterior = produto.Estoque;
            if (request.Estoque < 0 || request.EstoqueMinimo < 0) throw new Exception("O estoque não pode ser negativo.");
            produto.EstoqueMinimo = request.EstoqueMinimo;
            produto.ControlaEstoque = request.ControlaEstoque;
            // Item 7: o saldo novo entra pelo livro como "ajuste".
            var alerta = EstoqueService.AjustarPara(db, produto, request.Estoque,
                string.IsNullOrWhiteSpace(request.Motivo) ? "Ajuste no painel" : request.Motivo!,
                contextoEstoque.Usuario.Id, contextoEstoque.Usuario.Email);
            if (!produto.ControlaEstoque) produto.Estoque = request.Estoque;
            await db.SaveChangesAsync();
            if (alerta is not null) await AlertarEstoqueAsync(alerta);
            await realtime.NotificarAsync("produtos", "estoque", new { produto.Id, produto.Nome, produto.Estoque });
            await eventos.RegistrarAsync(new("produto", "Estoque ajustado", "info", "admin", contextoEstoque.Usuario.Id, contextoEstoque.Usuario.Email,
                produto.Id, $"{produto.Nome}: {estoqueAnterior} → {produto.Estoque} (mínimo {produto.EstoqueMinimo})."), HttpContext);
            return OkApi(new { produto.Id, produto.Nome, produto.Estoque, produto.EstoqueMinimo, produto.ControlaEstoque, message = "Estoque atualizado." });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    public record EstoqueRequest(string? Token, int Estoque, int EstoqueMinimo, bool ControlaEstoque, string? Motivo = null);

    // -----------------------------------------------------------------------
    // ITEM 7 — LIVRO DE ESTOQUE
    // -----------------------------------------------------------------------

    /// <summary>Entrada, saida ou ajuste manual de estoque (Produtos > Editar).</summary>
    [HttpPost("produtos/{id}/movimentacao")]
    public async Task<IActionResult> Movimentar(string id, [FromBody] MovimentacaoRequest request)
    {
        try
        {
            var contexto = await permissoes.ExigirAsync(request.Token ?? "", ModulosAdmin.Produtos, AcaoPermissao.Editar);
            var produto = await db.Produtos.FindAsync(id) ?? throw new Exception("Produto não encontrado.");
            if (!produto.ControlaEstoque) throw new Exception("Ligue o controle de estoque deste produto antes de lançar movimentações.");
            var tipo = Normalizador.Texto(request.Tipo);
            if (!EstoqueService.TiposManuais.Contains(tipo)) throw new Exception("Tipo de movimentação inválido. Use entrada, saída ou ajuste.");
            var motivo = (request.Motivo ?? "").Trim();
            if (motivo.Length < 3) throw new Exception("Informe o motivo da movimentação (ex.: compra do fornecedor, avaria, inventário).");
            if (motivo.Length > 200) throw new Exception("O motivo pode ter no máximo 200 caracteres.");
            var antes = produto.Estoque;
            EstoqueService.Alerta? alerta;
            if (tipo == EstoqueService.Ajuste)
            {
                if (request.Quantidade < 0) throw new Exception("No ajuste, informe o saldo correto (0 ou mais).");
                if (request.Quantidade == produto.Estoque) throw new Exception($"O saldo já é {produto.Estoque}.");
                alerta = EstoqueService.AjustarPara(db, produto, request.Quantidade, motivo, contexto.Usuario.Id, contexto.Usuario.Email);
            }
            else
            {
                if (request.Quantidade < 1 || request.Quantidade > 100000) throw new Exception("Informe uma quantidade entre 1 e 100000.");
                alerta = EstoqueService.Movimentar(db, produto, tipo == EstoqueService.Entrada ? request.Quantidade : -request.Quantidade,
                    tipo, motivo, contexto.Usuario.Id, contexto.Usuario.Email);
            }
            await db.SaveChangesAsync();
            await realtime.NotificarAsync("produtos", "estoque", new { produto.Id, produto.Nome, produto.Estoque });
            await eventos.RegistrarAsync(new("estoque", $"Estoque: {EstoqueService.RotuloTipo(tipo).ToLowerInvariant()}", "info", "admin",
                contexto.Usuario.Id, contexto.Usuario.Email, produto.Id, $"{produto.Nome}: {antes} → {produto.Estoque} · {motivo}"), HttpContext);
            if (alerta is not null) await AlertarEstoqueAsync(alerta);
            return OkApi(new { produto.Id, produto.Nome, produto.Estoque, produto.EstoqueMinimo, situacaoEstoque = EstoqueService.Situacao(produto), message = "Movimentação registrada." });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    /// <summary>Historico de movimentacoes (de um produto ou de todos), mais recentes primeiro.</summary>
    [HttpGet("estoque/movimentacoes")]
    public async Task<IActionResult> Movimentacoes([FromQuery] string token = "", [FromQuery] string? produtoId = null, [FromQuery] int limite = 50)
    {
        try
        {
            await permissoes.ExigirAsync(token, ModulosAdmin.Produtos, AcaoPermissao.Visualizar);
            limite = Math.Clamp(limite, 1, 500);
            var consulta = db.MovimentacoesEstoque.AsNoTracking();
            if (!string.IsNullOrWhiteSpace(produtoId)) consulta = consulta.Where(m => m.ProdutoId == produtoId);
            var lista = (await consulta.ToListAsync()).OrderByDescending(m => m.DataHora).Take(limite);
            return OkApi(lista.Select(m => new
            {
                m.Id, dataHora = DateTime.SpecifyKind(m.DataHora, DateTimeKind.Utc).ToString("O"), m.ProdutoId, m.ProdutoNome,
                m.Tipo, tipoRotulo = EstoqueService.RotuloTipo(m.Tipo), m.Quantidade, m.SaldoAnterior, m.SaldoNovo,
                m.Motivo, m.PedidoId, m.Origem, m.Autor
            }));
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    /// <summary>Muda o status de um pedido. Cancelar devolve o estoque baixado.</summary>
    [HttpPost("pedidos/{id}/status")]
    public async Task<IActionResult> StatusPedido(string id, [FromBody] StatusPedidoRequest request)
    {
        try
        {
            var contexto = await permissoes.ExigirAsync(request.Token ?? "", ModulosAdmin.Pedidos, AcaoPermissao.Editar);
            var pedido = await db.Pedidos.FirstOrDefaultAsync(p => p.Id == id) ?? throw new Exception("Pedido não encontrado.");
            if (!contexto.VeUnidade(pedido.Unidade)) throw new AcessoNegadoException("Este pedido é de outra unidade.");
            var antes = PedidosService.Exibir(pedido.Status);
            var devolvido = await PedidosService.AlterarStatusAsync(db, pedido, request.Status, contexto.Usuario.Id, contexto.Usuario.Email, "admin");
            await db.SaveChangesAsync();
            await PagamentosService.ReconciliarAsync(db);   // item 8
            await realtime.NotificarAsync("pedidos", "status", new { pedido.Id, pedido.Status });
            await eventos.RegistrarAsync(new("pedido", pedido.Status == PedidosService.Cancelado ? "Pedido cancelado" : "Status do pedido alterado",
                pedido.Status == PedidosService.Cancelado ? "aviso" : "info", "admin", contexto.Usuario.Id, contexto.Usuario.Email, pedido.Id,
                $"{antes} → {pedido.Status} · {pedido.Quantidade}× {pedido.ProdutoNome}" + (devolvido > 0 ? $" · {devolvido} unidade(s) devolvida(s) ao estoque" : "")), HttpContext);
            return OkApi(new
            {
                pedido.Id, pedido.Status, devolvido,
                message = pedido.Status == PedidosService.Cancelado
                    ? devolvido > 0 ? $"Pedido cancelado. {devolvido} unidade(s) voltaram ao estoque." : "Pedido cancelado. Não havia baixa de estoque para devolver."
                    : $"Pedido marcado como {pedido.Status}."
            });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    private Task AlertarEstoqueAsync(EstoqueService.Alerta a) =>
        eventos.RegistrarAsync(new("estoque", a.Zerado ? "Produto sem estoque" : "Estoque baixo", "aviso", "sistema", "", "",
            a.ProdutoId, $"{a.ProdutoNome}: saldo {a.Saldo} (mínimo {a.Minimo})."), HttpContext);

    public record MovimentacaoRequest(string? Token, string? Tipo, int Quantidade, string? Motivo);
    public record StatusPedidoRequest(string? Token, string? Status);

    [HttpGet("entradas-saidas")]
    public async Task<IActionResult> Lancamentos([FromQuery] string token = "", [FromQuery] string? de = null, [FromQuery] string? ate = null)
    {
        try
        {
            await permissoes.ExigirAsync(token, ModulosAdmin.Pagamentos, AcaoPermissao.Visualizar);
            var linhas = await db.EntradasESaidas.AsNoTracking().ToListAsync();
            return OkApi(linhas
                .Where(e => string.IsNullOrEmpty(de) && string.IsNullOrEmpty(ate) || Normalizador.Dentro(Normalizador.Data(e.Data), de, ate))
                .OrderByDescending(e => e.Data)
                .Select(e => new { e.Id, e.Data, e.Descricao, e.Tipo, e.Valor, e.Unidade, e.Origem }));
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    [HttpGet("pacotes")]
    public async Task<IActionResult> Pacotes([FromQuery] string token = "")
    {
        try
        {
            var contexto = await permissoes.ExigirAsync(token, ModulosAdmin.Pets, AcaoPermissao.Visualizar);
            var pacotes = await db.Pacotes.AsNoTracking().OrderByDescending(p => p.DataInicio).ToListAsync();
            return OkApi(pacotes.Where(p => contexto.VeUnidade(p.Unidade)).ToList());
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    /// <summary>Pedidos da loja com o nome do cliente resolvido (o admin nao tinha essa tela).</summary>
    [HttpGet("pedidos")]
    public async Task<IActionResult> Pedidos([FromQuery] string token = "")
    {
        try
        {
            var contextoPedidos = await permissoes.ExigirAsync(token, ModulosAdmin.Pedidos, AcaoPermissao.Visualizar);
            // Item 5: pedido tem unidade de retirada; funcionario ve so a dele.
            var pedidos = (await db.Pedidos.AsNoTracking().OrderByDescending(p => p.CriadoEm).ToListAsync())
                .Where(p => contextoPedidos.VeUnidade(p.Unidade)).ToList();
            var clientes = await db.Clientes.AsNoTracking().ToDictionaryAsync(c => c.Id, c => c);
            return OkApi(pedidos.Select(p => new
            {
                p.Id,
                p.ClienteId,
                cliente = clientes.TryGetValue(p.ClienteId, out var c) ? c.Nome : "(cliente removido)",
                telefone = clientes.TryGetValue(p.ClienteId, out var c2) ? c2.Telefone : "",
                p.ProdutoId,
                p.ProdutoNome,
                p.Quantidade,
                p.Total,
                p.FormaPagamento,
                p.Status,
                unidade = Normalizador.IdUnidade(p.Unidade),
                unidadeNome = Normalizador.NomeUnidade(p.Unidade) is { Length: > 0 } nomeUnidade ? nomeUnidade : "Sem unidade",
                criadoEm = p.CriadoEm.ToString("O")
            }));
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    // -----------------------------------------------------------------------
    // IMPORTACAO DO QUE SO EXISTIA NO NAVEGADOR
    // -----------------------------------------------------------------------

    /// <summary>
    /// Recebe o conteudo do localStorage do painel e grava no banco apenas o
    /// que ainda nao existe la. Nada e sobrescrito e nada e apagado: registros
    /// ja presentes sao contados como "ja existiam".
    /// Com simular = true nada e gravado — serve para conferir antes.
    /// </summary>
    [HttpPost("importar")]
    public async Task<IActionResult> Importar([FromBody] JsonElement corpo)
    {
        try
        {
            // A importacao grava em varias colecoes de uma vez, entao so quem
            // tem Configurações pode dispara-la.
            await permissoes.ExigirAsync(Texto(corpo, "token"), ModulosAdmin.Configuracoes, AcaoPermissao.Criar);
            var simular = corpo.TryGetProperty("simular", out var s) && s.ValueKind == JsonValueKind.True;
            var relatorio = new Dictionary<string, object>();

            relatorio["servicos"] = await ImportarServicos(Lista(corpo, "servicos"), simular);
            relatorio["produtos"] = await ImportarProdutos(Lista(corpo, "produtos"), simular);
            relatorio["pets"] = await ImportarPets(Lista(corpo, "pets"), simular);
            relatorio["agendamentos"] = await ImportarAgendamentos(Lista(corpo, "agendamentos"), simular);
            relatorio["entradasESaidas"] = await ImportarLancamentos(Lista(corpo, "entradasESaidas"), simular);

            if (!simular)
            {
                await db.SaveChangesAsync();
                await PagamentosService.ReconciliarAsync(db);   // item 8: agendamentos importados ganham pagamento
                await realtime.NotificarAsync("importacao", "concluida", relatorio);
            }

            return OkApi(new { simulacao = simular, relatorio, message = simular ? "Simulacao concluida: nada foi gravado." : "Importacao concluida." });
        }
        catch (Exception ex) { return ErrorApi(ex); }
    }

    private sealed record ResultadoImportacao(int Novos, int JaExistiam, int Ignorados);

    private async Task<ResultadoImportacao> ImportarServicos(List<JsonElement> linhas, bool simular)
    {
        var existentes = (await db.Servicos.AsNoTracking().ToListAsync())
            .Select(x => Chave(x.Nome, x.Porte)).ToHashSet();
        int novos = 0, repetidos = 0, ignorados = 0;
        foreach (var linha in linhas)
        {
            var nome = Texto(linha, "nome");
            if (nome.Length == 0) { ignorados++; continue; }
            var porte = Texto(linha, "porte");
            if (!existentes.Add(Chave(nome, porte))) { repetidos++; continue; }
            novos++;
            if (simular) continue;
            db.Servicos.Add(new Servico
            {
                Id = NovoId("SRV"),
                Nome = nome,
                Preco = Numero(linha, "preco"),
                Porte = porte,
                AdicionaisJson = Bruto(linha, "adicionais") ?? "[]",
                Pacote = Booleano(linha, "pacote") ? "Sim" : "",
                Adicional = Texto(linha, "adicional")
            });
        }
        return new ResultadoImportacao(novos, repetidos, ignorados);
    }

    private async Task<ResultadoImportacao> ImportarProdutos(List<JsonElement> linhas, bool simular)
    {
        var existentes = (await db.Produtos.AsNoTracking().ToListAsync())
            .Select(x => Chave(x.Codigo)).ToHashSet();
        int novos = 0, repetidos = 0, ignorados = 0;
        foreach (var linha in linhas)
        {
            var codigo = Texto(linha, "codigo");
            var nome = Texto(linha, "nome");
            if (codigo.Length == 0 && nome.Length == 0) { ignorados++; continue; }
            if (!existentes.Add(Chave(codigo.Length > 0 ? codigo : nome))) { repetidos++; continue; }
            novos++;
            if (simular) continue;
            db.Produtos.Add(new Produto
            {
                Id = NovoId("PRD"),
                Codigo = codigo,
                Nome = nome,
                Categoria = Texto(linha, "categoria"),
                ValorCompra = Numero(linha, "valorCompra"),
                ValorVenda = Numero(linha, "valorVenda"),
                Estoque = (int)Numero(linha, "estoque"),
                EstoqueMinimo = (int)Numero(linha, "estoqueMinimo"),
                ControlaEstoque = Numero(linha, "estoque") > 0
            });
        }
        return new ResultadoImportacao(novos, repetidos, ignorados);
    }

    private async Task<ResultadoImportacao> ImportarPets(List<JsonElement> linhas, bool simular)
    {
        var existentes = (await db.Pets.AsNoTracking().ToListAsync())
            .Select(x => Chave(x.Dono, x.PetNome)).ToHashSet();
        var clientes = await db.Clientes.ToListAsync();
        int novos = 0, repetidos = 0, ignorados = 0;
        foreach (var linha in linhas)
        {
            var dono = Texto(linha, "dono");
            var pet = Texto(linha, "pet");
            if (pet.Length == 0) { ignorados++; continue; }
            if (!existentes.Add(Chave(dono, pet))) { repetidos++; continue; }
            novos++;
            if (simular) continue;

            var telefone = Texto(linha, "telefone");
            var endereco = Texto(linha, "endereco");
            var cliente = clientes.FirstOrDefault(c => Normalizador.Texto(c.Nome) == Normalizador.Texto(dono));
            if (cliente is null && dono.Length > 0)
            {
                cliente = new Cliente { Id = NovoId("CLI"), Nome = dono, Telefone = telefone, Endereco = endereco, Origem = "importacao_painel", Status = "ativo" };
                db.Clientes.Add(cliente);
                clientes.Add(cliente);
            }

            db.Pets.Add(new Pet
            {
                Id = NovoId("PET"),
                ClienteId = cliente?.Id ?? "",
                Dono = dono,
                PetNome = pet,
                Tipo = Texto(linha, "tipo"),
                Raca = Texto(linha, "raca"),
                Telefone = telefone,
                Endereco = endereco,
                PacoteJson = Bruto(linha, "pacote") ?? "",
                Unidade = Texto(linha, "unidade")
            });
        }
        return new ResultadoImportacao(novos, repetidos, ignorados);
    }

    private async Task<ResultadoImportacao> ImportarAgendamentos(List<JsonElement> linhas, bool simular)
    {
        var existentes = (await db.Agendamentos.AsNoTracking().ToListAsync())
            .Select(x => Chave(x.Dono, x.Pet, Normalizador.Data(x.DataHora), (x.DataHora ?? "").Length >= 16 ? x.DataHora[11..16] : "")).ToHashSet();
        int novos = 0, repetidos = 0, ignorados = 0;
        foreach (var linha in linhas)
        {
            var dataHora = Texto(linha, "dataHora");
            var pet = Texto(linha, "pet");
            if (dataHora.Length == 0 || pet.Length == 0) { ignorados++; continue; }
            var dono = Texto(linha, "dono");
            if (!existentes.Add(Chave(dono, pet, Normalizador.Data(dataHora), dataHora.Length >= 16 ? dataHora[11..16] : ""))) { repetidos++; continue; }
            novos++;
            if (simular) continue;
            db.Agendamentos.Add(new Agendamento
            {
                Id = NovoId("AGD"),
                Pet = pet,
                Dono = dono,
                Telefone = Texto(linha, "telefone"),
                DataHora = dataHora,
                ServicosJson = Bruto(linha, "servicos") ?? "[]",
                Total = Numero(linha, "total"),
                Transporte = Texto(linha, "transporte"),
                ValorTransporte = Numero(linha, "valorTransporte"),
                Status = StatusAgendamento.Exibir(Texto(linha, "status")),   // item 4: importacao grava o nome novo
                PagamentoStatus = Texto(linha, "pagamentoStatus"),
                FormaPagamento = Texto(linha, "formaPagamento"),
                Obs = Texto(linha, "obs"),
                Unidade = Texto(linha, "unidade")
            });
        }
        return new ResultadoImportacao(novos, repetidos, ignorados);
    }

    private async Task<ResultadoImportacao> ImportarLancamentos(List<JsonElement> linhas, bool simular)
    {
        var existentes = (await db.EntradasESaidas.AsNoTracking().ToListAsync())
            .Select(x => Chave(Normalizador.Data(x.Data), x.Descricao, x.Tipo, x.Valor.ToString("0.00"))).ToHashSet();
        int novos = 0, repetidos = 0, ignorados = 0;
        foreach (var linha in linhas)
        {
            var data = Texto(linha, "data");
            var valor = Numero(linha, "valor");
            if (data.Length == 0) { ignorados++; continue; }
            var descricao = Texto(linha, "descricao");
            var tipo = Texto(linha, "tipo");
            if (!existentes.Add(Chave(Normalizador.Data(data), descricao, tipo, valor.ToString("0.00")))) { repetidos++; continue; }
            novos++;
            if (simular) continue;
            db.EntradasESaidas.Add(new EntradaSaida
            {
                Id = NovoId("FIN"),
                Data = data,
                Descricao = descricao,
                Tipo = tipo,
                Valor = valor,
                Unidade = Texto(linha, "unidade"),
                Origem = "importacao_painel"
            });
        }
        return new ResultadoImportacao(novos, repetidos, ignorados);
    }

    // -----------------------------------------------------------------------
    // AUXILIARES DE LEITURA DO JSON (o localStorage guarda numeros como texto
    // em alguns registros antigos, entao cada campo e lido com tolerancia)
    // -----------------------------------------------------------------------

    private static string NovoId(string prefixo) => prefixo + "-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant();
    private static string Chave(params string?[] partes) => string.Join("|", partes.Select(Normalizador.Texto));

    private static List<JsonElement> Lista(JsonElement corpo, string nome)
        => corpo.TryGetProperty(nome, out var valor) && valor.ValueKind == JsonValueKind.Array
            ? valor.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.Object).ToList()
            : new List<JsonElement>();

    private static string Texto(JsonElement objeto, string nome)
    {
        if (!objeto.TryGetProperty(nome, out var valor)) return "";
        return valor.ValueKind switch
        {
            JsonValueKind.String => valor.GetString()?.Trim() ?? "",
            JsonValueKind.Number => valor.ToString(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            _ => ""
        };
    }

    private static decimal Numero(JsonElement objeto, string nome)
    {
        if (!objeto.TryGetProperty(nome, out var valor)) return 0m;
        if (valor.ValueKind == JsonValueKind.Number && valor.TryGetDecimal(out var d)) return d;
        var texto = (valor.ValueKind == JsonValueKind.String ? valor.GetString() : null) ?? "";
        texto = texto.Replace("R$", "").Trim();
        if (texto.Contains(',')) texto = texto.Replace(".", "").Replace(',', '.');
        return decimal.TryParse(texto, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var parsed) ? parsed : 0m;
    }

    private static bool Booleano(JsonElement objeto, string nome)
        => objeto.TryGetProperty(nome, out var valor) && (valor.ValueKind == JsonValueKind.True || (valor.ValueKind == JsonValueKind.String && Normalizador.Texto(valor.GetString()) is "sim" or "true"));

    private static string? Bruto(JsonElement objeto, string nome)
        => objeto.TryGetProperty(nome, out var valor) && valor.ValueKind is JsonValueKind.Array or JsonValueKind.Object
            ? valor.GetRawText()
            : null;
}
